﻿using System.ComponentModel.DataAnnotations;

namespace BlazorDapperExample.Data
{
    public class SALESDTO
    {

        public int SalesId { get; set; }
        [Required(ErrorMessage = "Please Product Name")]
        public string ProductName { get; set; }
        [Required(ErrorMessage = "Please Product Quantity")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "Please enter  Quantity")]

        public bool IsUpdate { get; set; } = false;




    }
}
