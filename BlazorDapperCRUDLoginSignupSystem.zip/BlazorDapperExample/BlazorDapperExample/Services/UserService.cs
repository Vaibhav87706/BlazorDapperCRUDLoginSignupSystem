﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using BlazorDapperExample.Authentation;

public class UserService
{
    private readonly IConfiguration _configuration;

    public UserService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task CreateUserAsync(Signup signup)
    {
        try
        {
            // Create a new user in the database using Dapper
            using IDbConnection dbConnection = new SqlConnection(_configuration.GetConnectionString("DevDB"));

            // Define a SQL query to insert a new user into the database
            string query = "INSERT INTO LoginTable (username, password, Role) " +
                           "VALUES ( @username, @password, @Role)";

            // Execute the SQL query with the signup data
            await dbConnection.ExecuteAsync(query, new
            {
                
                userName = signup.username,
                password = signup.password,
                Role = "admin"
            
            });
        }
        catch (Exception ex)
        {
            // Handle any database or other exceptions here
            throw new ApplicationException("Error creating user: " + ex.Message);
        }
    }
}
