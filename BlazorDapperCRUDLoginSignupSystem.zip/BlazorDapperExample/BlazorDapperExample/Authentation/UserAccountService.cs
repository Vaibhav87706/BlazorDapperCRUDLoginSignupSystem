﻿using System.Data;
using System.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace BlazorDapperExample.Authentation
{
    public class UserAccountService
    {

        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public UserAccountService(IConfiguration configuration)
        {

            _connectionString = configuration.GetConnectionString("DevDB");
            _configuration = configuration;

        }
        //private List<UserAccount> _users;



        //public UserAccountService()
        //{


        //    _users = new List<UserAccount>
        //    {
        //        new UserAccount { UserName = "admin", Password = "admin", Role = "Administrator" },
        //        new UserAccount { UserName = "user", Password = "user", Role = "User" },


        //    };
        //}




        public async Task<UserAccount> GetByUserName(string username, string password)
        
        {
            try
            {
                using (IDbConnection con = new SqlConnection(_connectionString))
                {
                    con.Open();

                    var para = new DynamicParameters();
                    para.Add("@username", username);
                    para.Add("@password", password);

                    // Call the stored procedure
                    var result = await con.QueryAsync<UserAccount>(
                        "GetUserByCredentials", // Name of the stored procedure
                        para,
                        commandType: CommandType.StoredProcedure);

                    return result.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred during stored procedure execution: " + ex.Message);
                return null;
            }
        }
    }
}