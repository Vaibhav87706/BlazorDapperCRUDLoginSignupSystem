﻿namespace BlazorDapperExample.Authentation
{
    public class UserAccount
    {
        public int id { get; set; }

        public string username { get; set; }

        public string password { get; set; }

        public string Role { get; set; }

    }
}
