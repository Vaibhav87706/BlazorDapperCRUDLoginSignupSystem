﻿namespace BlazorDapperExample.Authentation
{
    public class UserSession
    {
        public string UserName { get; set; }

        public string password { get; set; }

        public string Role { get; set; }
    }
}
