﻿using System.ComponentModel.DataAnnotations;

namespace BlazorDapperExample.Authentation
{
    public class Signup
    {
        public  int id { get; set; }

        [Required(ErrorMessage = "Username is required.")]
        public string username { get; set; }

        [Required(ErrorMessage = "passsword is required.")]
        public string password { get; set; }

    }
}
