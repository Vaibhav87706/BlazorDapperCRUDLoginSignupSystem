﻿namespace BlazorDapperExample.Authentation
{
    internal class congfiguration
    {
    }
}