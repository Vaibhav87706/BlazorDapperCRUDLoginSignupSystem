﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using System.Security.Claims;

namespace BlazorDapperExample.Authentation
{
    public class CustomAuthentationStateProvider : AuthenticationStateProvider
    {
        private readonly ProtectedSessionStorage _sessionStroage;
        private ClaimsPrincipal _anonymous = new ClaimsPrincipal(new ClaimsIdentity());


        public CustomAuthentationStateProvider(ProtectedSessionStorage sessionStroage)
        {
            _sessionStroage = sessionStroage;
        }





        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {


            try
            {

                var UserSessionStroageResult = await _sessionStroage.GetAsync<UserSession>("UserSession");
                var userSession = UserSessionStroageResult.Success ? UserSessionStroageResult.Value : null;
                if (userSession == null)
                    return await Task.FromResult(new AuthenticationState(_anonymous));
                var ClaimsPricipal = new ClaimsPrincipal(new ClaimsIdentity(new List<Claim>
                 {

                     new Claim(ClaimTypes.Name, userSession.UserName),
                     new Claim(ClaimTypes.Role, userSession.Role)

                 }, "CustomAuth"));
                return await Task.FromResult(new AuthenticationState(ClaimsPricipal));


            }

            catch

            {
                return await Task.FromResult(new AuthenticationState(_anonymous));
            }

            
        }

        public async Task UpdateAuthenticationState(UserSession userSession)
        {
            ClaimsPrincipal claimsPrincipal;

            if(userSession != null)
            {
                await _sessionStroage.SetAsync("UserSession", userSession);
                claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity(new List<Claim>
                {
                    new Claim(ClaimTypes.Name, userSession.UserName),
                    new Claim(ClaimTypes.Role, userSession.Role)
                }));

            }
            else
            {
                await _sessionStroage.DeleteAsync("UserSession");
                claimsPrincipal = _anonymous;
            }

            NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(claimsPrincipal)));
        }
    }
}
