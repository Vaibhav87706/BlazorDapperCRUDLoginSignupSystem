﻿namespace BlazorDapperExample.Authentation
{
   
    public class Logindummycs
    {
        public string username { get; set; }
        public string password { get; set; }
    }

}
